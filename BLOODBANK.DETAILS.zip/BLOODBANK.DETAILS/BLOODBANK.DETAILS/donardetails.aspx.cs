﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


using System.Data.SqlClient;
using System.Data;


namespace BLOODBANK.DETAILS
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btnsubdonardetails_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\blood bank\BLOODBANK.DETAILS\BLOODBANK.DETAILS\App_Data\bloodbankdata.mdf;Integrated Security=True;Connect Timeout=30");
                SqlCommand cmd = new SqlCommand("insert into DonarInfo(DonarName,DonarAGE,Gender,BloodGroup,EyesOk,OrgansOK,MobileNumber,EmailID,GovtIDProof,ProofNumber,Status,NecessaryData,DonarCondition,Address,RegDate,StaffName,LocationData,BloodAmount) VALUES(@DonarName,@DonarAGE,@Gender,@BloodGroup,@EyesOk,@OrgansOK,@MobileNumber,@EmailID,@GovtIDProof,@ProofNumber,@Status,@NecessaryData,@DonarCondition,@Address,@RegDate,@StaffName,@LocationData,@BloodAmount)", con);


                SqlParameter Name = new SqlParameter();
                Name.SqlDbType = SqlDbType.NVarChar;
                Name.Direction = ParameterDirection.InputOutput;
                Name.ParameterName = "@DonarName";
                Name.Value = txtDonarName.Text;
                cmd.Parameters.Add(Name);


                SqlParameter Age = new SqlParameter();
                Age.SqlDbType = SqlDbType.Int;
                Age.Direction = ParameterDirection.InputOutput;
                Age.ParameterName = "@DonarAGE";
                Age.Value = ddlDonarAge.SelectedItem.ToString();
                cmd.Parameters.Add(Age);


                SqlParameter gender = new SqlParameter();
                gender.SqlDbType = SqlDbType.VarChar;
                gender.Direction = ParameterDirection.InputOutput;
                gender.ParameterName = "@Gender";
                gender.Value = ddlDonarGender.SelectedItem.ToString();
                cmd.Parameters.Add(gender);


                SqlParameter blood = new SqlParameter();
                blood.SqlDbType = SqlDbType.NVarChar;
                blood.Direction = ParameterDirection.InputOutput;
                blood.ParameterName = "@BloodGroup";
                blood.Value = ddlbloodgrp.SelectedItem.ToString();
                cmd.Parameters.Add(blood);


                SqlParameter eye = new SqlParameter();
                eye.SqlDbType = SqlDbType.NChar;
                eye.Direction = ParameterDirection.InputOutput;
                eye.ParameterName = "@EyesOk";
                eye.Value = ddleyes.SelectedItem.ToString();
                cmd.Parameters.Add(eye);


                SqlParameter organs = new SqlParameter();
                organs.SqlDbType = SqlDbType.NChar;
                organs.Direction = ParameterDirection.InputOutput;
                organs.ParameterName = "@OrgansOK";
                organs.Value = ddlorgans.SelectedItem.ToString();
                cmd.Parameters.Add(organs);

                SqlParameter PhoneNumber = new SqlParameter();
                PhoneNumber.SqlDbType = SqlDbType.BigInt;
                PhoneNumber.Direction = ParameterDirection.InputOutput;
                PhoneNumber.ParameterName = "@MobileNumber";
                PhoneNumber.Value = txtDonarMobileno.Text;
                cmd.Parameters.Add(PhoneNumber);

                SqlParameter Email = new SqlParameter();
                Email.SqlDbType = SqlDbType.NVarChar;
                Email.Direction = ParameterDirection.InputOutput;
                Email.ParameterName = "@EmailID";
                Email.Value = txtDonaremail.Text;
                cmd.Parameters.Add(Email);



                SqlParameter govtid = new SqlParameter();
                govtid.SqlDbType = SqlDbType.NVarChar;
                govtid.Direction = ParameterDirection.InputOutput;
                govtid.ParameterName = "@GovtIDProof";
                govtid.Value = ddlgovtprof.SelectedItem.ToString();
                cmd.Parameters.Add(govtid);

                SqlParameter govtnumber = new SqlParameter();
                govtnumber.SqlDbType = SqlDbType.NVarChar;
                govtnumber.Direction = ParameterDirection.InputOutput;
                govtnumber.ParameterName = "@ProofNumber";
                govtnumber.Value = txtProofNumber.Text;
                cmd.Parameters.Add(govtnumber);


                SqlParameter status = new SqlParameter();
                status.SqlDbType = SqlDbType.NVarChar;
                status.Direction = ParameterDirection.InputOutput;
                status.ParameterName = "@Status";
                status.Value = ddlStatus.SelectedItem.ToString();
                cmd.Parameters.Add(status);

                SqlParameter Neccdata = new SqlParameter();
                Neccdata.SqlDbType = SqlDbType.NVarChar;
                Neccdata.Direction = ParameterDirection.InputOutput;
                Neccdata.ParameterName = "@NecessaryData";
                Neccdata.Value = ddlnecessarydata.SelectedItem.ToString();
                cmd.Parameters.Add(Neccdata);


                SqlParameter donarcondition = new SqlParameter();
                donarcondition.SqlDbType = SqlDbType.NVarChar;
                donarcondition.Direction = ParameterDirection.InputOutput;
                donarcondition.ParameterName = "@DonarCondition";
                donarcondition.Value = ddlDonarCondition.SelectedItem.ToString();
                cmd.Parameters.Add(donarcondition);

                SqlParameter address = new SqlParameter();
                address.SqlDbType = SqlDbType.NVarChar;
                address.Direction = ParameterDirection.InputOutput;
                address.ParameterName = "@Address";
                address.Value = txtDonarAddress.Text;
                cmd.Parameters.Add(address);

                SqlParameter regData = new SqlParameter();
                regData.SqlDbType = SqlDbType.NVarChar;
                regData.Direction = ParameterDirection.InputOutput;
                regData.ParameterName = "@RegDate";
                regData.Value = Calendar1.SelectedDate.ToString();
                cmd.Parameters.Add(regData);

                SqlParameter staffName = new SqlParameter();
                staffName.SqlDbType = SqlDbType.NVarChar;
                staffName.Direction = ParameterDirection.InputOutput;
                staffName.ParameterName = "@StaffName";
                staffName.Value = txtStaffname.Text;
                cmd.Parameters.Add(staffName);


                SqlParameter location = new SqlParameter();
                location.SqlDbType = SqlDbType.NVarChar;
                location.Direction = ParameterDirection.InputOutput;
                location.ParameterName = "@LocationData";
                location.Value = ddllocationdetails.SelectedItem.ToString();
                cmd.Parameters.Add(location);


                SqlParameter bloodamt = new SqlParameter();
                bloodamt.SqlDbType = SqlDbType.NVarChar;
                bloodamt.Direction = ParameterDirection.InputOutput;
                bloodamt.ParameterName = "@BloodAmount";
                bloodamt.Value = ddlBloodCollected.SelectedItem.ToString();
                cmd.Parameters.Add(bloodamt);
                if (CheckBox1.Checked)
                {
                    int dataAdded = -1;

                    con.Open();

                    dataAdded = cmd.ExecuteNonQuery();
                    con.Close();


                    if (dataAdded == 1)
                    {
                        string alert = string.Format("<script>alert('Thanks for giving blood--details added')</script>");
                        ClientScript.RegisterStartupScript(this.GetType(), null, alert);
                    }
                    else
                    {
                        string alert = string.Format("<script>alert('DATA NOT ADDED')</script>");
                        ClientScript.RegisterStartupScript(this.GetType(), null, alert);
                    }


                }

                else
                {
                    lblExeception.Text = "click the check out ";
                }
            }
            catch (SqlException ex)
            {
                lblExeception.Text = ex.Message.ToString();
            }
            catch (MissingPrimaryKeyException ex)
            {
                lblExeception.Text = ex.Message.ToString();
            }
            catch (Exception ex)
            {
                lblExeception.Text = ex.Message.ToString();
            }






        }

        protected void btnDonarDetails_Click(object sender, EventArgs e)
        {
            Response.Redirect("ViewDetails.aspx");
        }

        protected void btnreset_Click(object sender, EventArgs e)
        {
            txtDonarName.Text = string.Empty;
            ddlDonarAge.ClearSelection();
            ddlDonarGender.ClearSelection();
            ddlbloodgrp.ClearSelection();
            ddlStatus.ClearSelection();
            ddlDonarCondition.ClearSelection();
            txtDonarAddress.Text = string.Empty;
            ddlnecessarydata.ClearSelection();

            ddleyes.ClearSelection();
            ddlorgans.ClearSelection();
            ddlgovtprof.ClearSelection();
            Calendar1.SelectedDates.Clear();

            txtDonaremail.Text = string.Empty;
            txtDonarMobileno.Text = string.Empty;
            txtProofNumber.Text = string.Empty;
            txtStaffname.Text = string.Empty;
        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {

        }

        protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        
    }
}