﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Data;

namespace BLOODBANK.DETAILS
{
    public partial class WebForm7 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\blood bank\BLOODBANK.DETAILS\BLOODBANK.DETAILS\App_Data\bloodbankdata.mdf;Integrated Security=True;Connect Timeout=30");

            SqlCommand cmd = new SqlCommand("insert into DonarfeedBack(DonarName,EmailId,Location,Suggestion) values(@DonarName,@EmailId,@Location,@Suggestion)", con);
            

            SqlParameter Name = new SqlParameter();
            Name.SqlDbType = SqlDbType.NVarChar;
            Name.Direction = ParameterDirection.InputOutput;
            Name.ParameterName = "@DonarName";
            Name.Value = TextBox1.Text;
            cmd.Parameters.Add(Name);


            SqlParameter email = new SqlParameter();
            email.SqlDbType = SqlDbType.NVarChar;
            email.Direction = ParameterDirection.InputOutput;
            email.ParameterName = "@EmailId";
            email.Value = TextBox2.Text;
            cmd.Parameters.Add(email);


            SqlParameter gender = new SqlParameter();
            gender.SqlDbType = SqlDbType.VarChar;
            gender.Direction = ParameterDirection.InputOutput;
            gender.ParameterName = "@Location";
            gender.Value = TextBox3.Text;
            cmd.Parameters.Add(gender);


            SqlParameter blood = new SqlParameter();
            blood.SqlDbType = SqlDbType.NVarChar;
            blood.Direction = ParameterDirection.InputOutput;
            blood.ParameterName = "@Suggestion";
            blood.Value = TextBox4.Text;
            cmd.Parameters.Add(blood);

            int dataAdded = -1;

            con.Open();

            dataAdded = cmd.ExecuteNonQuery();
            con.Close();


            if (dataAdded == 1)
            {
                string alert = string.Format("<script>alert('Thanks for giving feedback')</script>");
                ClientScript.RegisterStartupScript(this.GetType(), null, alert);
            }
            else
            {
                string alert = string.Format("<script>alert('feedback not registered')</script>");
                ClientScript.RegisterStartupScript(this.GetType(), null, alert);
            }


        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            TextBox1.Text = string.Empty;
            TextBox2.Text = string.Empty;
            TextBox3.Text = string.Empty;
            TextBox4.Text = string.Empty;

            TextBox1.Focus();

        }
    }
}