﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;

namespace BLOODBANK.DETAILS
{
    public partial class Contact : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnclearlogin_Click(object sender, EventArgs e)
        {
            TextBox1.Text = string.Empty;
            TextBox2.Text = string.Empty;

           

            TextBox1.Focus();
        }


        protected void btnlogin_Click1(object sender, EventArgs e)
        {
           
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\blood bank\BLOODBANK.DETAILS\BLOODBANK.DETAILS\App_Data\bloodbankdata.mdf;Integrated Security=True;Connect Timeout=30");

          

            SqlCommand cmd = new SqlCommand("SELECT * FROM InternalLogin WHERE UserName=@UserName and Password=@Password", con);
          //  cmd.CommandType = CommandType.StoredProcedure;

            SqlParameter empid = new SqlParameter();
            empid.SqlDbType = SqlDbType.NVarChar;
            empid.ParameterName = "@UserName";
            empid.Direction = ParameterDirection.Input;
            empid.Value =TextBox1.Text;
            cmd.Parameters.Add(empid);


            SqlParameter pwd = new SqlParameter();
            pwd.SqlDbType = SqlDbType.VarChar;
            pwd.ParameterName = "@Password";
            pwd.Direction = ParameterDirection.Input;
            pwd.Value = TextBox2.Text;
            cmd.Parameters.Add(pwd);

            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                dr.Read();

                Response.Redirect("donardetails.aspx");


            }

            con.Close();
        }




        }
    }
